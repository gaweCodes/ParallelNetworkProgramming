﻿using System.Windows;

namespace Pitfall6
{
    public partial class App : Application
    {
    }
}
