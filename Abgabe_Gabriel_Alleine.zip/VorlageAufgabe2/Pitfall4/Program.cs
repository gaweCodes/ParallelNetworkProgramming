﻿namespace Pitfall4 
{
    internal class Program
    {
        private static void Main() => new RaceSample().TestRunAsync().Wait();
    }
}