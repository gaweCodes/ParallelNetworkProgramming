﻿using System.Windows;

namespace TestUIThread
{
    public partial class App : Application
    {
    }
}
