﻿namespace DiningPhilosopherTestat
{
    internal class Fork
    {
        internal bool IsUsed { get; set; }
    }
}
